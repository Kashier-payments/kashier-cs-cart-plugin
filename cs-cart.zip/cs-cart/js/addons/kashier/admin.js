jQuery().ready(function ($) {
  jQuery(document).ready(function () {
    var curr = window.location.pathname;
    var curr1 = curr.split('/');
    var url =
      window.location.origin +
      '/' +
      curr1[1] +
      '/index.php?dispatch=payment_notification.callback&payment=kashier';

    document.getElementById('kashier_callback_url').value = url;
  });
});
