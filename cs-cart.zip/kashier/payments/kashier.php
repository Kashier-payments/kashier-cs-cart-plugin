<?php
use Tygh\Registry;
require __DIR__ . '/helpers/pay-helper.php';

if (!defined('BOOTSTRAP')) { die('Access denied'); }
if (defined('PAYMENT_NOTIFICATION')) {
  if ($mode == 'result' ) {
    fn_change_order_status($_REQUEST['order_id'], 'P', '', false);
    fn_set_notification('N', __('order_placed'), __('text_order_placed_successfully'));
    fn_order_placement_routines('route', $_REQUEST['order_id'], false);

  } 
  elseif ($mode == 'failure') {

    $msg=__('text_transaction_declined');
    fn_set_notification('E', '', $msg);
    fn_change_order_status($_REQUEST['order_id'], 'F', '', false);
    fn_order_placement_routines('checkout_redirect', $_REQUEST['order_id'], false);

  } elseif ($mode == 'cancel') {
  
    // if (fn_check_payment_script('kashier.php', $_REQUEST['order_id'])) {
    //   $response = array();
    //   $response['order_status'] = 'I';
    //   $response['reason_text']  = __('text_transaction_cancelled');
    //   fn_finish_payment($_REQUEST['order_id'], $response);
    // }
    $msg=__('text_transaction_cancelled');
    fn_set_notification('E', '', $msg);
    fn_change_order_status($_REQUEST['order_id'], 'I', '', false);
    fn_order_placement_routines('checkout_redirect', $_REQUEST['order_id'], false);

  }elseif($mode == 'callback'){

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
      $obj  = $_REQUEST;
      $data = $_GET;
    } else {
      die('METHOD "' . $_SERVER['REQUEST_METHOD'] . '" NOT ALLOWED');
    }

    $order_id = substr($data['merchantOrderId'], 0, -11);
    $order_info = fn_get_order_info( $order_id, true);
    $order_id=$order_info['order_id'];

    if (empty($processor_data)) {
       $processor_data = fn_get_processor_data($order_info['payment_id']);
    }

    $config = [
        "merchant_id" =>$processor_data['processor_params']['kashier_merchant_id'],
        "api_key" => $processor_data['processor_params']['kashier_mode'] == 'test' ? $processor_data['processor_params']['kashier_test_api_key'] : $processor_data['processor_params']['kashier_live_api_key'],
        "mode"  => $processor_data['processor_params']['kashier_mode'],
        "currency" =>$processor_data['processor_params']['kashier_currency'],
        "can_debug" =>$processor_data['processor_params']['kashier_can_debug'],
        "gateway_code" => $processor_data['processor_params']['kashier_gateway_code'],
    ];

    $process = new PayHelper($order_info, $config);
    $isValidSignature = $process->signature($config['api_key'], $data);

    // auth?
    if($data['signature']){

      if ($isValidSignature) {
                    
            $order_id = substr($data['merchantOrderId'], 0, -11);

            if (
                $data['paymentStatus'] == 'SUCCESS'
            ) {
                
                // $this->order->add_order_note('TransactionId is '. $data['transactionId']);
                fn_change_order_status($order_id, 'p', '', false);
                $redirect_url=Registry::get('config.http_location')."/index.php?dispatch=payment_notification.result&payment=kashier&order_id=$order_id";
                fn_redirect($redirect_url, true);
            
            } else {
            var_dump(  $data['paymentStatus']);
                fn_change_order_status($order_id, 'f', '', false);
                $redirect_url=Registry::get('config.http_location')."/index.php?dispatch=payment_notification.failure&payment=kashier&order_id=$order_id";
                fn_redirect($redirect_url, true);
                // fn_change_order_status($order_id, 'N', '', false);

            }
        
        
          } else {
              die('HMAC Failed to validate.');
          }
      } else {
        if (
          $data['paymentStatus'] == 'serverError'
        ) {
            
            // $this->order->add_order_note('TransactionId is '. $data['transactionId']);
            fn_change_order_status($order_id, 'f', '', false);
            $redirect_url=Registry::get('config.http_location')."/index.php?dispatch=payment_notification.failure&payment=kashier&order_id=$order_id";
            fn_redirect($redirect_url, true);
        
        } elseif($data['paymentStatus'] == 'CANCELLED') {
        
            fn_change_order_status($order_id, 'i', '', false);
            $redirect_url=Registry::get('config.http_location')."/index.php?dispatch=payment_notification.cancel&payment=kashier&order_id=$order_id";
            fn_redirect($redirect_url, true);
            // fn_change_order_status($order_id, 'N', '', false);

        }
  
      } 
        // leave.
        exit();
    }
    }
 else {
  
  $order_id = $order_info['repaid'] ? $order_id . '_' . $order_info['repaid'] : $order_id;

  $config = [
    "method" => $processor_data['processor_params']['kashier_method'],
    "merchant_id" =>$processor_data['processor_params']['kashier_merchant_id'],
    "mode"  => $processor_data['processor_params']['kashier_mode'],
    "api_key" => $processor_data['processor_params']['kashier_mode'] == 'test' ? $processor_data['processor_params']['kashier_test_api_key'] : $processor_data['processor_params']['kashier_live_api_key'],
    "currency" =>$processor_data['processor_params']['kashier_currency'],
    "callback_url" => urlencode($processor_data['processor_params']['kashier_callback_url']),
    "brand_color" => urlencode($processor_data['processor_params']['kashier_brand_color']),
    "can_debug" =>$processor_data['processor_params']['kashier_can_debug'],
    "gateway_code" => $processor_data['processor_params']['kashier_gateway_code'],
    ];
    
    $process = new PayHelper($order_info, $config);
   
    if ( !$process->isValid() ){
        return $process->throwErrors("Please solve all the errors below.");
    }

    $redirect_url='https://checkout.kashier.io/?merchantId='.$process->merchant_id.'&allowedMethods='.$process->method.'&orderId='.$process->order_unique_id.'&mode='.$process->mode.'&amount='.$process->amount.'&currency='.$process->currency.'&hash='.$process->hash.'&metaData='.$process->metaData.'&merchantRedirect='.$process->callback_url.'&redirectMethod=get'.'&brandColor='.$process->brand_color.'&display='.$process->renderLanguage;
    fn_redirect($redirect_url, true);

}
