<?php
class PayHelper
{

    public function __construct($order, Array $config)
    {
        $this->order                = $order;
        $this->method               = $config['method'];  
        $this->merchant_id          = $config['merchant_id'];
        $this->api_key              = $config['api_key'];
        $this->mode                 = $config['mode'];
        $this->callback_url         = $config['callback_url'];
        $this->brand_color          = $config['brand_color'];
        $this->debug                = $config['can_debug'];
        $this->currency             = $config['currency'];
        $this->gateway_code         = $config['gateway_code'];
        $this->renderLanguage = CART_LANGUAGE == 'ar' ? 'ar' : 'en';
        $this->processOrderData();

    }

    public function isValid()
    {
        return $this->is_valid;
    }

    public function processOrderData()
    {
        try {
            $order = $this->order;
        
            $this->order_unique_id = $order['order_id'].'_'. time();
            $this->order_currency  = $order['payment_method']['processor_params']['kashier_currency'];
            $this->amount = $order['total'];
           
            $this->hash = $this->hash( $this->merchant_id ,$this->api_key, $this->order_unique_id , $this->amount, $this->order_currency);

            $this->metaData =json_encode([
                'CustomerEmail'          => $order['email'],
                'CustomerPhoneNumber'    => $order['b_phone'],
                'CustomerLastName'       => str_replace(' ', '-', $order['b_lastname']),
                'CustomerFirstName'      => str_replace(' ', '-', $order['b_firstname']),
            ]);

            $this->processStoreConfig();

        } catch (\Exception $error) {
            throw new \Exception($error->getMessage());
        }

    }

    public function processStoreConfig()
    {
        $valid = true;
        $reasons = array();

        if ( !version_compare(PHP_VERSION, '5.4.0', '>=') )
        {
            $valid = false;
            $reasons[] = "Required php version >= 5.4.0, your PHP version is: " . PHP_VERSION;
        }

        if ( !extension_loaded('curl'))
        {
            $valid = false;
            $reasons[] = "Required php extension: cURL, this extension is not enabled on this server.";
        }

        $this->error = $reasons;
        $this->is_valid = $valid;
    }

    public function processOrder()
    {
        $this->order->update_status('pending-payment');
        $this->order->add_order_note('(Awaiting Payment)');
        $this->order->save();
    }

    public function getError()
    {
        $error = "";

        if (is_string($this->error) && $this->error != '')
        {
            $error .= "<li>$this->error</li>";

        } else if (is_array($this->error) && !empty($this->error)) {
            foreach ($this->error as $key => $data) {
                if(is_array($data))
                {
                    $hints  = "";
                    $field = "$key: ";
                    foreach ($data as $text)
                    {
                        $hints .= " $text ";
                    }
                }else{
                    $field = "";
                    $hints = $data;
                }

                $error .= "<li>$field$hints</li>";
            }
        }

        return $error;
    }

    public function throwErrors($error)
    {
        if( $this->debug )
        {
            global $woocommerce;
            global $wp_version;
            $version = 'KASHIER_PLUGIN_VERSION';
            echo "<!-- You are seeing this because you have debug turned on in your payment settings -->";
          //  print_r($this->response_raw_data);
          //  echo "<!-- WooCommerce settings/Payments/Payment method/ Uncheck Debugger box. -->";
        }

        if( isset($_REQUEST['pay_for_order']) && $_REQUEST['pay_for_order'] === "true" ){
            wc_add_notice($error, 'error');
        }else{
            throw new Exception($error);
        }
    }

 

    public static function hash($mid, $secret, $orderId, $amount, $currency)
    {        
        $path = "/?payment=".$mid.".".$orderId.".".$amount.".".$currency;
        $hash = hash_hmac( 'sha256' , $path , $secret ,false);
        return $hash;

    }

    public static function signature($secret, $data){
        $queryString=null;
        foreach ($data as $key => $value) {
            if($key == "signature" || $key== "mode"|| $key== "dispatch"|| $key== "payment"){
                continue;
            }
          
            $queryString = $queryString."&".$key."=".$value;
        }
     
        $queryString = ltrim($queryString, $queryString[0]);
            $signature = hash_hmac( 'sha256' , $queryString , $secret ,false);
        if($signature == $_GET["signature"]){
            return true;
        }else{
            return false;
        }
    }

   
}
